"""
PyAutoFix Ultimate - AI-Powered Code Correction
"""

__version__ = "2.0.0"
__author__ = "PyAutoFix Team"

# No imports needed - main function is in main.py at root level
# This file just provides package metadata

__all__ = []