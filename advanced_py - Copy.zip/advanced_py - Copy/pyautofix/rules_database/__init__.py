from .default_rules import DEFAULT_RULES

__all__ = [
    'DEFAULT_RULES'
]